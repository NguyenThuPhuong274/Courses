<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="refresh" content="0;url=https://tiengnhatcolam.vn" />

        <title>Redirecting to https://tiengnhatcolam.vn</title>
    </head>
    <body>
        Redirecting to <a href="https://tiengnhatcolam.vn">https://tiengnhatcolam.vn</a>.
    </body>
</html>